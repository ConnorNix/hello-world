# hello-world

Connor here, im a millenial groundworker from the uk, im new to most of this but i truly believe blockchain is the future to all our ecomonic and enviromental issues humanity currently faces. And its pretty shit being a groundworker.
